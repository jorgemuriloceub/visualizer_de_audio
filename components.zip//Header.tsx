import { Search, Moon, Sun, Download, MessageCircle } from 'lucide-react';
import { useTheme } from './ThemeProvider';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useState } from 'react';

export function Header() {
  const { theme, toggleTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      console.log('Pesquisando:', searchQuery);
      // Aqui você pode adicionar a lógica de pesquisa
    }
  };

  return (
    <header className="w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4 mb-4">
          {/* Baixar Música - Esquerda */}
          <a
            href="https://www.palcomp3.com.br/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <Download className="size-5" />
            <span>Baixar Música</span>
          </a>

          {/* Tema Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full"
            aria-label="Alternar tema"
          >
            {theme === 'light' ? (
              <Moon className="size-5" />
            ) : (
              <Sun className="size-5" />
            )}
          </Button>

          {/* Fale Conosco - Direita */}
          <button className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <MessageCircle className="size-5" />
            <span>Fale Conosco</span>
          </button>
        </div>

        {/* Barra de Pesquisa Central */}
        <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Pesquisar músicas, artistas, álbuns..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-6 bg-input-background"
            />
          </div>
        </form>
      </div>
    </header>
  );
}
