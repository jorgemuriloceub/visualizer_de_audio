import { Button } from './ui/button';
import { Music, Play } from 'lucide-react';

interface HeroProps {
  onStart: () => void;
}

export function Hero({ onStart }: HeroProps) {
  return (
    <section className="flex-1 flex items-center justify-center px-4 py-20">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <div className="flex justify-center mb-6">
          <div className="p-6 bg-primary/10 rounded-full">
            <Music className="size-16 text-primary" />
          </div>
        </div>
        
        <h1 className="text-5xl md:text-6xl tracking-tight">
          Descubra e ouça suas músicas favoritas
        </h1>
        
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Explore milhões de músicas de todos os gêneros. Crie suas playlists, descubra novos artistas e muito mais.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <Button
            size="lg"
            onClick={onStart}
            className="px-8 py-6 gap-2"
          >
            <Play className="size-5" />
            Comece Agora
          </Button>
          
          <a
            href="https://www.palcomp3.com.br/"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button
              variant="outline"
              size="lg"
              className="px-8 py-6"
            >
              Baixar Músicas
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
}
