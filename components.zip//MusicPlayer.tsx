import { Button } from './ui/button';
import { ArrowLeft } from 'lucide-react';

interface MusicPlayerProps {
  onBack: () => void;
}

export function MusicPlayer({ onBack }: MusicPlayerProps) {
  return (
    <div className="size-full flex flex-col bg-background">
      <div className="p-4 border-b border-border">
        <Button
          variant="ghost"
          onClick={onBack}
          className="gap-2"
        >
          <ArrowLeft className="size-5" />
          Voltar para Início
        </Button>
      </div>

      <div className="flex-1 flex items-center justify-center p-8">
        <div className="max-w-4xl w-full text-center space-y-6">
          <h1>Player de Música</h1>
          <p className="text-muted-foreground">
            Esta é a página do player de música. Aqui você pode adicionar seu player personalizado.
          </p>
        </div>
      </div>
    </div>
  );
}
