import { Music2, Guitar, Mic2, Disc3, Radio, Volume2 } from 'lucide-react';

const musicGenres = [
  {
    name: 'Sertanejo',
    icon: Guitar,
    description: 'O melhor da música sertaneja',
    color: 'text-amber-500'
  },
  {
    name: 'Rock',
    icon: Music2,
    description: 'Clássicos e modernos do rock',
    color: 'text-red-500'
  },
  {
    name: 'Rap',
    icon: Mic2,
    description: 'Hip hop e rap nacional e internacional',
    color: 'text-purple-500'
  },
  {
    name: 'Pop',
    icon: Disc3,
    description: 'Os maiores sucessos pop',
    color: 'text-pink-500'
  },
  {
    name: 'Eletrônica',
    icon: Radio,
    description: 'EDM, house, techno e mais',
    color: 'text-blue-500'
  },
  {
    name: 'MPB',
    icon: Volume2,
    description: 'Música Popular Brasileira',
    color: 'text-green-500'
  }
];

export function Footer() {
  return (
    <footer className="w-full border-t border-border bg-background">
      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <h2 className="text-center mb-2">Explore por Gênero</h2>
          <p className="text-center text-muted-foreground">
            Descubra músicas de todos os estilos
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {musicGenres.map((genre) => {
            const Icon = genre.icon;
            return (
              <button
                key={genre.name}
                className="flex items-start gap-4 p-4 rounded-lg border border-border hover:bg-accent transition-colors text-left"
              >
                <div className={`p-3 rounded-full bg-accent ${genre.color}`}>
                  <Icon className="size-6" />
                </div>
                <div className="flex-1">
                  <h3>{genre.name}</h3>
                  <p className="text-muted-foreground text-sm">
                    {genre.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="text-center text-sm text-muted-foreground pt-8 border-t border-border">
          <p>&copy; 2025 Music App. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
